# PassGen
Password generation with JavaScript .
It takes length of password as an input ,
Then we have to choose what we want in password ,
i.e. (A-Z) ,(a-z) ,(0-9) ,(!-*) .
